from pandocmath._version import __version__

import pandocmath.pandocmath
